function board=moveTicTacToe(board,row,col,player)
    board(row,col)=player;
end