function weights=generalize(trainingMatrix, weights)
    weights=LMSAlgoritm(trainingMatrix,weights);
end