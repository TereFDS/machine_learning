function board=experimentGenerator(weights)
    board= zeros(3,3);
end